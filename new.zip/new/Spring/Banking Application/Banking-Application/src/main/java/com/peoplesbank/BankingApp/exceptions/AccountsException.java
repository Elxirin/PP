package com.peoplesbank.BankingApp.exceptions;

public class AccountsException extends Exception {
	
	public AccountsException(String message) {
		super(message);
	}

}
