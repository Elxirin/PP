
export interface Transaction {
    tranId: number;
    accId: number;
    tranDate: string;
    description: string;
    tranType: string;
    amount: number;
}